CREATE DATABASE raceday;

-- RaceDay Database Schema
-- SQL Server (SSMS) compatible


-- Drop tables if they exist (in correct order due to FKs)
IF OBJECT_ID('Result', 'U') IS NOT NULL DROP TABLE Result;
IF OBJECT_ID('Enrolment', 'U') IS NOT NULL DROP TABLE Enrolment;
IF OBJECT_ID('Category', 'U') IS NOT NULL DROP TABLE Category;
IF OBJECT_ID('Event', 'U') IS NOT NULL DROP TABLE Event;
IF OBJECT_ID('Venue', 'U') IS NOT NULL DROP TABLE Venue;
IF OBJECT_ID('User', 'U') IS NOT NULL DROP TABLE [User];
GO


-- 1. User table

CREATE TABLE [User] (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    email NVARCHAR(255) NOT NULL UNIQUE,
    password_hash NVARCHAR(255) NOT NULL,
    role NVARCHAR(20) NOT NULL CHECK (role IN ('organiser', 'participant')),
    created_at DATETIME DEFAULT GETDATE()
);
GO


-- 2. Venue table

CREATE TABLE Venue (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    address NVARCHAR(255) NOT NULL,
    capacity INT
);
GO


-- 3. Event table

CREATE TABLE Event (
    id INT IDENTITY(1,1) PRIMARY KEY,
    name NVARCHAR(100) NOT NULL,
    description NVARCHAR(MAX),
    date DATETIME NOT NULL,
    organiser_id INT NOT NULL,
    venue_id INT NOT NULL,
    status NVARCHAR(20) NOT NULL CHECK (status IN ('draft', 'open', 'closed', 'completed')),
    FOREIGN KEY (organiser_id) REFERENCES [User](id),
    FOREIGN KEY (venue_id) REFERENCES Venue(id)
);
GO

-- 4. Category table

CREATE TABLE Category (
    id INT IDENTITY(1,1) PRIMARY KEY,
    event_id INT NOT NULL,
    name NVARCHAR(50) NOT NULL,
    age_group NVARCHAR(20),
    gender NVARCHAR(10),
    distance_km DECIMAL(5,2),
    FOREIGN KEY (event_id) REFERENCES Event(id) ON DELETE CASCADE
);
GO


-- 5. Enrolment table

CREATE TABLE Enrolment (
    id INT IDENTITY(1,1) PRIMARY KEY,
    event_id INT NOT NULL,
    category_id INT NOT NULL,
    participant_id INT NOT NULL,
    registration_date DATETIME DEFAULT GETDATE(),
    status NVARCHAR(20) NOT NULL CHECK (status IN ('pending', 'confirmed', 'cancelled')),
    payment_status NVARCHAR(20) NOT NULL CHECK (payment_status IN ('unpaid', 'paid')),
    FOREIGN KEY (event_id) REFERENCES Event(id),
    FOREIGN KEY (category_id) REFERENCES Category(id),
    FOREIGN KEY (participant_id) REFERENCES [User](id)
);
GO


-- 6. Result table

CREATE TABLE Result (
    id INT IDENTITY(1,1) PRIMARY KEY,
    enrolment_id INT NOT NULL UNIQUE,
    finish_time_seconds INT,
    position INT,
    points INT,
    FOREIGN KEY (enrolment_id) REFERENCES Enrolment(id)
);
GO


-- Sample Data Insertion


-- Insert 2 Organisers
INSERT INTO [User] (name, email, password_hash, role)
VALUES 
    ('Alice Organiser', 'alice@raceday.com', 'hashed_password_1', 'organiser'),
    ('Bob Organiser', 'bob@raceday.com', 'hashed_password_2', 'organiser');

-- Insert 2 Participants
INSERT INTO [User] (name, email, password_hash, role)
VALUES 
    ('Charlie Runner', 'charlie@runner.com', 'hashed_password_3', 'participant'),
    ('Diana Athlete', 'diana@athlete.com', 'hashed_password_4', 'participant');

-- Insert Venues
INSERT INTO Venue (name, address, capacity)
VALUES 
    ('Central Park', '123 Park Ave, NYC', 500),
    ('Lakeside Stadium', '456 Lake Dr, LA', 300);

-- Insert Events (Alice organises first, Bob organises second)
INSERT INTO Event (name, description, date, organiser_id, venue_id, status)
VALUES 
    ('Spring 10K Run', 'Annual spring 10 km race', '2026-05-15 08:00:00', 1, 1, 'open'),
    ('Summer Marathon', 'Full marathon along the lake', '2026-07-20 06:00:00', 2, 2, 'open');

-- Insert Categories for Event 1
INSERT INTO Category (event_id, name, age_group, gender, distance_km)
VALUES 
    (1, '10K Men', '18-39', 'M', 10.0),
    (1, '10K Women', '18-39', 'F', 10.0),
    (1, '10K Masters', '40+', 'All', 10.0);

-- Insert Categories for Event 2
INSERT INTO Category (event_id, name, age_group, gender, distance_km)
VALUES 
    (2, 'Full Marathon', '18-39', 'All', 42.2),
    (2, 'Half Marathon', '18-39', 'All', 21.1);

-- Insert Enrolments (participant 3 enrols in event1 cat1, participant 4 enrols in event1 cat2 and event2 cat1)
INSERT INTO Enrolment (event_id, category_id, participant_id, status, payment_status)
VALUES 
    (1, 1, 3, 'confirmed', 'paid'),
    (1, 2, 4, 'pending', 'unpaid'),
    (2, 4, 4, 'confirmed', 'paid');   -- event2 category id = 4 (Full Marathon)

-- Insert Results (for enrolment 1 and 3)
INSERT INTO Result (enrolment_id, finish_time_seconds, position, points)
VALUES 
    (1, 3600, 5, 10),   -- 1 hour
    (3, 7200, 3, 15);   -- 2 hours

GO





 





