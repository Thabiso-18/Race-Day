# RaceDay - Event Management System

## 📋 System Overview

**RaceDay** is a comprehensive event management platform designed specifically for athletic race organisers and participants. The system streamlines the entire race management process from event creation to result tracking.

### Core Functionality

- **Organisers** can create and manage events, define race categories, handle participant enrolments, and record race results.
- **Participants** can browse events, enrol in categories, view their enrolment history, and access their race results.
- **Role-based access control** ensures appropriate permissions for each user type.
- **RESTful API** provides clean, documented endpoints for all system operations.
- **SQL Server database** with proper relational design ensures data integrity.

---

## 👥 User Roles

### Organiser

- Create, update, and delete events
- Add and manage event categories (age groups, gender, distances)
- View all participant enrolments for their events
- Approve or cancel enrolments
- Record race results (finish times, positions, points)
- Update event status (draft, open, closed, completed)

### Participant

- Browse all available events
- View event details and categories
- Enrol in categories for specific events
- Cancel their own enrolments
- View personal enrolment history
- Access their race results

---

## 🗄️ Database Design

### Entities (6 Core Tables)

| Entity | Description |
|--------|-------------|
| **User** | Stores all system users with authentication details and roles |
| **Venue** | Event locations with address and capacity information |
| **Event** | Race events with details, date, and status |
| **Category** | Event categories (age groups, gender, distance) |
| **Enrolment** | Participant registrations for events |
| **Result** | Race results linked to enrolments |

### Entity Relationship Diagram

![ERD](docs/erd.png)

*The ERD shows all entities, attributes, primary keys, foreign keys, and cardinalities. View the full diagram in the `/docs` folder.*

---

## 📡 API Endpoints

### Authentication & Profile

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register a new user |
| POST | `/api/auth/login` | Authenticate and receive JWT token |
| GET | `/api/profile` | Get current user profile |
| PUT | `/api/profile` | Update user profile |

### Events

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/events` | List all events with filters |
| GET | `/api/events/{id}` | Get specific event details |
| POST | `/api/events` | Create a new event (Organiser only) |
| PUT | `/api/events/{id}` | Update an event (Organiser only) |
| DELETE | `/api/events/{id}` | Delete an event (Organiser only) |

### Categories

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/events/{eventId}/categories` | Get categories for an event |
| POST | `/api/events/{eventId}/categories` | Add a category (Organiser only) |
| PUT | `/api/categories/{id}` | Update a category (Organiser only) |
| DELETE | `/api/categories/{id}` | Delete a category (Organiser only) |

### Enrolments & Results

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/events/{eventId}/enrol` | Enrol in an event (Participant) |
| GET | `/api/enrolments` | Get participant's enrolments |
| GET | `/api/events/{eventId}/enrolments` | Get event enrolments (Organiser) |
| PUT | `/api/enrolments/{id}/status` | Update enrolment status (Organiser) |
| DELETE | `/api/enrolments/{id}` | Cancel enrolment |
| POST | `/api/enrolments/{id}/result` | Record result (Organiser) |
| GET | `/api/events/{eventId}/results` | Get event results |

*Complete API endpoint specifications are available in `/docs/endpoints.md`.*

---

## 🗂️ Repository Structure

```text
RaceDay/
│
├── docs/
│   ├── erd.png
│   ├── endpoints.md
│   └── schema.sql
│
├── .github/
│   └── workflows/
│       └── validation.yml
│
├── README.md
└── ...
```

---

## 🛠️ Technology Stack

| Component | Technology |
|-----------|------------|
| Database | Microsoft SQL Server |
| API | RESTful API |
| Authentication | JWT |
| Version Control | Git / GitHub |
| CI/CD | GitHub Actions |
| Documentation | Markdown, PNG/PDF |

---

## 🚀 Getting Started

### Prerequisites

- SQL Server Management Studio (SSMS)
- Git
- GitHub account
- .NET SDK for Part 2 development
- Optional: Node.js/React for frontend development

### Database Setup

1. Open **SQL Server Management Studio (SSMS)**.
2. Create or select a clean database environment.
3. Run the SQL script:

```text
/docs/schema.sql
```

4. Verify that all six tables have been created.
5. Verify that the sample data has been inserted correctly.

### Repository Setup

Clone the repository:

```bash
git clone <YOUR-GITHUB-REPOSITORY-URL>
cd RaceDay
```

---

## ⚙️ CI/CD Pipeline

The repository includes a **GitHub Actions** workflow that validates the required project structure.

The pipeline checks that:

- The `/docs` folder exists.
- The ERD diagram is present.
- The API endpoint plan is present.
- The SQL script is present.
- Required documentation files exist.

### Build Status

![CI/CD Build Status](docs/build-status.png)

---

## 📚 Planning Documentation

All planning documentation is stored in the `/docs` folder.

### Entity Relationship Diagram

`docs/erd.png`

Contains:

- Six core entities
- Primary keys
- Foreign keys
- Relationships
- Cardinalities
- Attributes
- Constraints

### API Endpoint Plan

`docs/endpoints.md`

Contains:

- HTTP methods
- API routes
- Endpoint descriptions
- Role requirements
- Request details
- Response details

### Database Schema

`docs/schema.sql`

Contains:

- SQL table definitions
- Primary keys
- Foreign keys
- Constraints
- Sample data

---

## 🧪 Testing

The RaceDay system should be tested to ensure that all planned functionality works correctly.

Testing areas include:

- User registration
- User login
- JWT authentication
- Role-based authorisation
- Event creation
- Event updates
- Event deletion
- Category management
- Participant enrolment
- Enrolment cancellation
- Enrolment approval
- Result recording
- Result retrieval
- Input validation
- Error handling

---

## 📊 Sample Data

The database can contain sample records for demonstration and testing.

### Users

- **Alice Organiser** - Organiser
- **Bob Organiser** - Organiser
- **Charlie Runner** - Participant
- **Diana Athlete** - Participant

### Events

1. **Spring 10K Run** - Open - Central Park - 15 May 2026
2. **Summer Marathon** - Open - Lakeside Stadium - 20 July 2026
3. **Autumn Trail Race** - Draft - Central Park - 10 October 2026

### Categories

- Event 1: 10K Men, 10K Women, 10K Masters
- Event 2: Full Marathon, Half Marathon
- Event 3: Trail Run

---

## 🎥 Video Walkthrough

A complete planning walkthrough can be added to the project repository.

**RaceDay System Planning Walkthrough:**

`https://youtu.be/your-video-link`

> Replace the placeholder link above with the actual YouTube video link before submission.

The video should demonstrate:

- System overview
- User roles
- ERD design
- Database design
- API endpoint planning
- SQL script execution
- GitHub repository structure
- CI/CD validation

---

## 🎯 Learning Outcomes

This project demonstrates:

- Relational database design
- Entity Relationship Diagram development
- Primary and foreign key implementation
- SQL Server database development
- RESTful API planning
- Role-based access control
- JWT authentication planning
- Git and GitHub version control
- GitHub Actions CI/CD
- Technical documentation

---

## ✅ Submission Checklist

- [x] ERD image in `/docs`
- [x] API endpoint plan in `/docs`
- [x] SQL script in `/docs`
- [x] README with system description and roles
- [x] Database entities documented
- [x] API endpoints documented
- [x] CI/CD workflow configured
- [x] Build screenshot included
- [x] YouTube walkthrough link prepared
- [x] GitHub repository created
- [x] Meaningful Git commits completed

---

## 🚀 Project Status

**Part 1: Planning and Database Design — Complete ✅**

**Part 2: API Development and Implementation — Ready to Begin 🚀**

---

## 📄 License

© The Independent Institute of Education (Pty) Ltd 2026

This project is developed for academic and educational purposes.

---

## 🏁 RaceDay

**Plan. Register. Race. Results.**
