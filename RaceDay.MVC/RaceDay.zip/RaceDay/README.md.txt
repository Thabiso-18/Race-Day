# RaceDay - Event Management System

## 📋 System Overview

**RaceDay** is a comprehensive event management platform designed specifically for athletic race organisers and participants. The system streamlines the entire race management process from event creation to result tracking.

### Core Functionality

- **Organisers** can create and manage events, define race categories, handle participant enrolments, and record race results
- **Participants** can browse events, enrol in categories, view their enrolment history, and access their race results
- **Role-based access control** ensures appropriate permissions for each user type
- **RESTful API** provides clean, documented endpoints for all system operations
- **SQL Server database** with proper relational design ensures data integrity

---

## 👥 User Roles

### Organiser
- Create, update, and delete events
- Add and manage event categories (age groups, gender, distances)
- View all participant enrolments for their events
- Approve or cancel enrolments
- Record race results (finish times, positions, points)
- Update event status (draft, open, closed, completed)

### Participant
- Browse all available events
- View event details and categories
- Enrol in categories for specific events
- Cancel their own enrolments
- View personal enrolment history
- Access their race results

---

## 🗄️ Database Design

### Entities (6 Core Tables)

| Entity | Description |
|--------|-------------|
| **User** | Stores all system users with authentication details and roles |
| **Venue** | Event locations with address and capacity information |
| **Event** | Race events with details, date, and status |
| **Category** | Event categories (age groups, gender, distance) |
| **Enrolment** | Participant registrations for events |
| **Result** | Race results linked to enrolments |

### Entity Relationship Diagram

![ERD](docs/erd.png)

*The ERD shows all entities, attributes, primary keys, foreign keys, and cardinalities. View the full diagram in the `/docs` folder.*

---

## 📡 API Endpoints

### Authentication & Profile
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register a new user |
| POST | `/api/auth/login` | Authenticate and receive JWT token |
| GET | `/api/profile` | Get current user profile |
| PUT | `/api/profile` | Update user profile |

### Events
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/events` | List all events with filters |
| GET | `/api/events/{id}` | Get specific event details |
| POST | `/api/events` | Create a new event (Organiser only) |
| PUT | `/api/events/{id}` | Update an event (Organiser only) |
| DELETE | `/api/events/{id}` | Delete an event (Organiser only) |

### Categories
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/events/{eventId}/categories` | Get categories for an event |
| POST | `/api/events/{eventId}/categories` | Add a category (Organiser only) |
| PUT | `/api/categories/{id}` | Update a category (Organiser only) |
| DELETE | `/api/categories/{id}` | Delete a category (Organiser only) |

### Enrolments & Results
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/events/{eventId}/enrol` | Enrol in an event (Participant) |
| GET | `/api/enrolments` | Get participant's enrolments |
| GET | `/api/events/{eventId}/enrolments` | Get event enrolments (Organiser) |
| PUT | `/api/enrolments/{id}/status` | Update enrolment status (Organiser) |
| DELETE | `/api/enrolments/{id}` | Cancel enrolment |
| POST | `/api/enrolments/{id}/result` | Record result (Organiser) |
| GET | `/api/events/{eventId}/results` | Get event results |

*Complete API endpoint specifications are available in `/docs/endpoints.md`*

---

## 🗂️ Repository Structure
